
package vendingmachine;

public class Product 
{
    public Product(int n, double p, int q)
    {
        productNumber = n;
        price = p;
        quantity = q;
    }
    
    // returns the price of a given product
    public double getPrice(Product p)
    {
        return p.price;
    }
    
    // returns the product number of a given product
    public int getProductNumber(Product p)
    {
        return p.productNumber;
    }
    
    // returns the quantity of a given product
    public int getQuantity(Product p)
    {
        return p.quantity;
    }
    
    // decreases the product quantity by 1
    public void decrementQuantity()
    {
        this.quantity = this.quantity - 1;
    }
    
    // restocks the product quantity
    public void restock(int q)
    {
        this.quantity = q;
    }
    
    int productNumber, quantity;
    double price;
}
