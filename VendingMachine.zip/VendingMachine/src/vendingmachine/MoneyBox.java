
package vendingmachine;

public class MoneyBox
{
    public MoneyBox()
    {
        cash = 0;
    }
    
    // compares the price of the product to the
    // amount input by the user
    public int compareTo(double u, double p)
    {
        if(u > p)
        {
            return 1;
        }
        else if(u == p)
        {
            return 0;
        }
        else
        {
            return -1;
        }
    }
    
    // returns the change for the user
    public double getChange(double u, double p)
    {
        return u - p;
    }
    
    // puts the money into the moneybox
    public void incrementCash(double p)
    {
        cash = cash + p;
    }
    
    // empties the moneybox
    public void takeCash()
    {
        cash = 0;
    }
    
    double cash;
}
