
package vendingmachine;

public class VendingMachine
{
    public void run()
    {
        // Creates 5 products
        this.product = new Product[5];

        // Gives each product a number, price, and quantity
        for (int i = 0; i < 5; i++)
        {
            this.product[i] = new Product(i+1, PRICE, QUANTITY);
        }
        
        // initializes the MoneyBox
        box = new MoneyBox();
        

        do
        {
            // Initializes the VendingMachineUI
            UI = new VendingMachineUI();

            // Gets the product number that the user wants
            userProd = UI.getUserProd();
            
            // determines whether the user input the password
            if(userProd == PASSWORD)
            {
                // empties the moneybox
                box.takeCash();
                
                // restocks the products
                for (int i = 0; i < 5; i++)
                {
                    this.product[i].restock(QUANTITY);
                }
                
                UI.restock();
            }
            else
            {
                // Gets the money the user inputs
                userMoney = UI.getUserMoney();

                // determines whether the user input sufficient money
                if(box.compareTo(userMoney, product[userProd].price) == -1)
                {
                    this.UI.insufficientMoney();

                }
                else if(this.product[userProd].quantity == 0)
                {
                    this.UI.unavailableProduct();
                }
                else
                {
                    // dispenses requested product
                    this.UI.dispense(box.getChange(userMoney, product[userProd].price));
                    
                    // increments cash in money box
                    this.box.incrementCash(product[userProd].price);
                    
                    // decrements product quantity
                    this.product[userProd].decrementQuantity();
                }
            }
            
            // determines if the user wants another product
            exit = this.UI.another();
            
        } 
        // continues while the user wants another product
        while(exit.equals("yes"));
        
        
    }
       
    final double PRICE = 1.25;
    final int QUANTITY = 3;
    final int PASSWORD = 1234;
    int userProd;
    double userMoney;
    VendingMachineUI UI;
    Product[] product;
    String exit = "yes";
    MoneyBox box;
}
