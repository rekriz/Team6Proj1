
package vendingmachine;

public class VendingMachineUI
{
    public VendingMachineUI ()
    {
        // initializes the Keypad
        keypad = new Keypad();        
        
        // get the product requested by user
        productNumber = keypad.getProductNumber();       
    }
    
    // gets the type of product the user wants
    public int getUserProd()
    {
        return productNumber;
    }
    
    // gets the amount of money the user inputs
    public double getUserMoney()
    {
        // gets the money the user inputs
        userMoney = keypad.getMoney();
        
        return userMoney;
    }
    
    // dispences the product to the user
    public void dispense(double c)
    {
        this.keypad.returnProduct();
        this.keypad.returnChange(c);
    }
    
    // tells the user he did not put in sufficient money
    public void insufficientMoney()
    {
        this.keypad.insufficientMoney();
    }
    
    // tells the user the product is unavailable
    public void unavailableProduct()
    {
        this.keypad.unavailableProduct();
    }
    
    // determines if the user wants another product
    public String another()
    {
        return this.keypad.another();
    }
    
    // tells the user that he has emptied the money box and restocked the product
    public void restock()
    {
        this.keypad.restock();
    }
    
    int productNumber;
    double userMoney;
    Keypad keypad;
}
