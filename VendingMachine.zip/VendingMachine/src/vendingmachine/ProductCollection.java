
package vendingmachine;

public class ProductCollection 
{
    
}
