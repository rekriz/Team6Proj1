
package vendingmachine;

import java.util.Scanner;

public class Keypad 
{
    public Keypad()
    {
        userInput = new Scanner(System.in);
    }
    
    // Receives the product number requested the user
    public int getProductNumber()
    {

        System.out.println("Please enter a product number 1-5: ");
        this.productNumber = userInput.nextInt();
        
        while((this.productNumber < 1 || this.productNumber > 5) && this.productNumber != PASSWORD)
        {
            if(this.productNumber < 1 || this.productNumber > 5)
            {
                System.out.println("Invalid product number.");  
            }
            
            System.out.println("Please enter a product number 1-5: ");
            this.productNumber = userInput.nextInt();  
        }
        
        return productNumber;
    }
    
    // Receives the amount of money input by the user
    public double getMoney()
    {
        System.out.println("Please enter appropriate amount of money: ");
        userMoney = userInput.nextDouble();
        return userMoney;
    }
    
    // returns the product to the user
    public void returnProduct()
    {
        System.out.println("Sufficient money. Please take Product.");
    }
    
    // returns the change to the user
    public void returnChange(double c)
    {
        System.out.println("Please take your change: $" + c);
    }
    
    // tells the user he did not put in sufficient money   
    public void insufficientMoney()
    {
        System.out.println("Insufficient money. Please try again.");
    }
    
    // tells the user the product is unavailable  
    public void unavailableProduct()
    {
        System.out.println("Product Unavailable. Please try again.");
    }
    
    // determines if the user wants another product
    public String another()
    {
        System.out.println("Would you like to purchase another product?");
        another = userInput.next();
        
        return another;       
    }
    
    // tells the user that he has emptied the money box and restocked the product
    public void restock()
    {
        System.out.println("Money box emptied. Product restocked");
    }
    
    Scanner userInput;
    int productNumber;
    double userMoney;
    String another;
    final int PASSWORD = 1234;
}
